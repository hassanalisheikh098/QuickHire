import { createContext, useContext, useState, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import { supabase } from '../lib/supabase'

const AuthContext = createContext(null)

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null)
  const [loading, setLoading] = useState(true)
  const navigate = useNavigate()

  useEffect(() => {
    // onAuthStateChange fires immediately with INITIAL_SESSION on subscribe,
    // which restores the existing session on page reload. No need for getSession().
    const { data: { subscription } } = supabase.auth.onAuthStateChange(async (event, session) => {
      const currentUser = session?.user ?? null

      if (currentUser) {
        // Always fetch and attach the profile, regardless of event type
        const { data: profile } = await supabase
          .from('profiles')
          .select('*')
          .eq('id', currentUser.id)
          .maybeSingle()

        if (profile) {
          // Merge DB profile data into user metadata
          currentUser.user_metadata = {
            ...currentUser.user_metadata,
            full_name: profile.full_name,
            role: profile.role
          }
        } else if (event === 'SIGNED_IN') {
          // New OAuth user — create their profile
          const oauthRole = localStorage.getItem('oauth_role') || null
          localStorage.removeItem('oauth_role')
          const fullName =
            currentUser.user_metadata?.full_name ||
            currentUser.user_metadata?.name ||
            'User'

          const { error: insertError } = await supabase
            .from('profiles')
            .insert({
              id: currentUser.id,
              email: currentUser.email,
              full_name: fullName,
              role: oauthRole,
            })

          if (insertError) {
            console.error('Error creating profile on SIGNED_IN:', insertError)
          }

          currentUser.user_metadata = {
            ...currentUser.user_metadata,
            full_name: fullName,
            role: oauthRole,
          }
        }

        setUser({ ...currentUser })
      } else {
        setUser(null)
      }

      setLoading(false)
    })

    return () => subscription.unsubscribe()
  }, [])

  const signUp = async (email, password, metadata = {}) => {
    const { data, error } = await supabase.auth.signUp({
      email,
      password,
      options: {
        data: {
          full_name: metadata.full_name,
          role: metadata.role || 'recruiter',
        }
      }
    })

    if (!error && data?.user) {
      // Create a profile record immediately to bypass triggers wait
      const { error: profileError } = await supabase
        .from('profiles')
        .upsert({
          id: data.user.id,
          email: email,
          full_name: metadata.full_name,
          role: metadata.role || 'recruiter',
        })
      if (profileError) console.error('Error creating profile in signUp:', profileError)
    }

    return { data, error }
  }

  const signIn = async (email, password) => {
    const { data, error } = await supabase.auth.signInWithPassword({
      email,
      password,
    })
    return { data, error }
  }

  const signInWithGoogle = async () => {
    const { data, error } = await supabase.auth.signInWithOAuth({
      provider: 'google',
      options: {
        redirectTo: `${window.location.origin}/auth`
      }
    })
    return { data, error }
  }

  const signOut = async () => {
    const { error } = await supabase.auth.signOut()
    setUser(null)
    navigate('/')
    return { error }
  }

  return (
    <AuthContext.Provider value={{ user, loading, signUp, signIn, signInWithGoogle, signOut }}>
      {children}
    </AuthContext.Provider>
  )
}

export function useAuth() {
  const ctx = useContext(AuthContext)
  if (!ctx) throw new Error('useAuth must be used within an AuthProvider')
  return ctx
}
